const API_BASE = 'http://127.0.0.1:8000/api';

document.addEventListener('DOMContentLoaded', async () => {
  const form = document.getElementById('jobForm');
  const titleInput = document.getElementById('jobTitle');
  const companyInput = document.getElementById('companyName');
  const locationInput = document.getElementById('jobLocation');
  const statusSelect = document.getElementById('jobStatus');
  const statusMessage = document.getElementById('statusMessage');
  const saveBtn = document.getElementById('saveBtn');
  const authNotice = document.getElementById('authNotice');
  const tokenInput = document.getElementById('authTokenInput');
  const saveTokenBtn = document.getElementById('saveTokenBtn');
  const userStatus = document.getElementById('userStatus');
  const userStatusText = document.getElementById('userStatusText');

  let currentDescription = '';
  let currentUrl = '';

  // 1. Check or Auto-Detect Token
  chrome.storage.local.get(['careeros_token', 'careeros_user'], (res) => {
    if (!res.careeros_token) {
      authNotice.style.display = 'block';
      userStatus.style.display = 'none';
    } else {
      authNotice.style.display = 'none';
      userStatus.style.display = 'flex';
      tokenInput.value = res.careeros_token;

      if (res.careeros_user) {
        try {
          const u = typeof res.careeros_user === 'string' ? JSON.parse(res.careeros_user) : res.careeros_user;
          userStatusText.innerText = `Connected: ${u.name || u.email || 'Active'}`;
        } catch (e) {
          userStatusText.innerText = 'Connected: Career OS Active';
        }
      } else {
        userStatusText.innerText = 'Connected: Career OS Active';
      }
    }
  });

  saveTokenBtn.addEventListener('click', () => {
    const val = tokenInput.value.trim();
    if (val) {
      chrome.storage.local.set({ careeros_token: val }, () => {
        authNotice.style.display = 'none';
        userStatus.style.display = 'flex';
        userStatusText.innerText = 'Connected: Career OS Active';
        showStatus('Token saved securely!', 'success');
      });
    }
  });

  // 2. Query active tab and request content script extraction
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id) {
      currentUrl = tab.url;
      chrome.tabs.sendMessage(tab.id, { action: 'SCRAPE_CURRENT_PAGE' }, (response) => {
        if (chrome.runtime.lastError || !response || !response.data) {
          return;
        }
        const data = response.data;
        if (data.title) titleInput.value = data.title;
        if (data.company) companyInput.value = data.company;
        if (data.location) locationInput.value = data.location;
        if (data.description) currentDescription = data.description;
        if (data.url) currentUrl = data.url;
      });
    }
  } catch (e) {
    console.error('Extraction handshake error:', e);
  }

  // 3. Handle Form Submit
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    saveBtn.disabled = true;
    saveBtn.innerText = 'Saving...';
    statusMessage.style.display = 'none';

    chrome.storage.local.get(['careeros_token'], async (res) => {
      const token = res.careeros_token;
      if (!token) {
        authNotice.style.display = 'block';
        showStatus('Please login to Career OS or enter your token.', 'error');
        saveBtn.disabled = false;
        saveBtn.innerText = '🚀 Save to Career OS Board';
        return;
      }

      try {
        const payload = {
          job_title: titleInput.value.trim(),
          company_name: companyInput.value.trim(),
          location: locationInput.value.trim(),
          status: statusSelect.value,
          job_description: currentDescription || 'Captured via Career OS Extension.',
          job_url: currentUrl
        };

        const response = await fetch(`${API_BASE}/jobs`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(payload)
        });

        const data = await response.json();
        if (!response.ok) {
          throw new Error(data.message || 'Server rejected application record.');
        }

        showStatus('🎉 Job successfully clipped to Career OS Kanban!', 'success');
        setTimeout(() => window.close(), 1800);
      } catch (err) {
        showStatus(err.message, 'error');
        saveBtn.disabled = false;
        saveBtn.innerText = '🚀 Save to Career OS Board';
      }
    });
  });

  function showStatus(text, type) {
    statusMessage.innerText = text;
    statusMessage.className = `status ${type}`;
    statusMessage.style.display = 'block';
  }
});
