const API_BASE = 'https://career-os-api-va3f.onrender.com/api';
const LOCAL_API_BASE = 'http://127.0.0.1:8000/api';

const FRONTEND_DOMAINS = [
  'https://livecareeros.vercel.app',
  'http://localhost:5173',
  'http://127.0.0.1:5173'
];

document.addEventListener('DOMContentLoaded', async () => {
  const form = document.getElementById('jobForm');
  const titleInput = document.getElementById('jobTitle');
  const companyInput = document.getElementById('companyName');
  const locationInput = document.getElementById('jobLocation');
  const statusSelect = document.getElementById('jobStatus');
  const statusMessage = document.getElementById('statusMessage');
  const saveBtn = document.getElementById('saveBtn');
  const authNotice = document.getElementById('authNotice');
  const loginCareerOsBtn = document.getElementById('loginCareerOsBtn');
  const userStatus = document.getElementById('userStatus');
  const userStatusText = document.getElementById('userStatusText');

  let currentDescription = '';
  let currentUrl = '';

  // 1. Function to detect auth cookies from Career OS web app
  async function autoDetectCookieToken() {
    return new Promise((resolve) => {
      let resolved = false;
      let checked = 0;

      FRONTEND_DOMAINS.forEach((domain) => {
        chrome.cookies.get({ url: domain, name: 'careeros_token' }, (cookie) => {
          checked++;
          if (!resolved && cookie && cookie.value) {
            resolved = true;
            resolve(cookie.value);
          } else if (checked === FRONTEND_DOMAINS.length && !resolved) {
            resolve(null);
          }
        });
      });
    });
  }

  // Helper to fetch user info with a token
  async function fetchUserProfile(token) {
    const endpoints = [API_BASE, LOCAL_API_BASE];
    for (const base of endpoints) {
      try {
        const res = await fetch(`${base}/user`, {
          headers: {
            'Accept': 'application/json',
            'Authorization': `Bearer ${token}`
          }
        });
        if (res.ok) {
          const data = await res.json();
          return { user: data.user || data, base };
        }
      } catch (e) {
        // Continue to fallback endpoint
      }
    }
    return null;
  }

  // Check stored token or auto-detect from cookies
  chrome.storage.local.get(['careeros_token', 'careeros_user', 'careeros_api_base'], async (res) => {
    let token = res.careeros_token;

    if (!token) {
      // Try auto-detecting from browser cookies
      token = await autoDetectCookieToken();
      if (token) {
        chrome.storage.local.set({ careeros_token: token });
      }
    }

    if (!token) {
      authNotice.style.display = 'block';
      userStatus.style.display = 'none';
    } else {
      authNotice.style.display = 'none';
      userStatus.style.display = 'flex';

      const profile = await fetchUserProfile(token);
      if (profile && profile.user) {
        chrome.storage.local.set({ 
          careeros_user: profile.user,
          careeros_api_base: profile.base
        });
        userStatusText.innerText = `Connected: ${profile.user.name || profile.user.email}`;
      } else {
        userStatusText.innerText = 'Connected: Career OS Active';
      }
    }
  });

  // Login with Career OS Button Handler (Auto-Redirect / Cookie Sync)
  if (loginCareerOsBtn) {
    loginCareerOsBtn.addEventListener('click', async () => {
      loginCareerOsBtn.disabled = true;
      loginCareerOsBtn.innerText = 'Checking Career OS...';

      const cookieToken = await autoDetectCookieToken();
      if (cookieToken) {
        chrome.storage.local.set({ careeros_token: cookieToken });
        authNotice.style.display = 'none';
        userStatus.style.display = 'flex';
        
        const profile = await fetchUserProfile(cookieToken);
        if (profile && profile.user) {
          userStatusText.innerText = `Connected: ${profile.user.name || profile.user.email}`;
        }
        showStatus('🎉 Successfully connected to Career OS!', 'success');
        loginCareerOsBtn.disabled = false;
        loginCareerOsBtn.innerText = '⚡ Login with Career OS';
        return;
      }

      // If not logged in on the web, open dashboard in a new tab
      chrome.tabs.create({ url: 'https://livecareeros.vercel.app/login' });
      showStatus('Please log in to Career OS in the opened tab, then click this button again.', 'error');
      loginCareerOsBtn.disabled = false;
      loginCareerOsBtn.innerText = '⚡ Login with Career OS';
    });
  }

  // 2. Query active tab and request content script extraction
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id) {
      currentUrl = tab.url;
      chrome.tabs.sendMessage(tab.id, { action: 'SCRAPE_CURRENT_PAGE' }, (response) => {
        if (chrome.runtime.lastError || !response || !response.data) {
          return;
        }
        const data = response.data;
        if (data.title) titleInput.value = data.title;
        if (data.company) companyInput.value = data.company;
        if (data.location) locationInput.value = data.location;
        if (data.description) currentDescription = data.description;
        if (data.url) currentUrl = data.url;
      });
    }
  } catch (e) {
    console.error('Extraction handshake error:', e);
  }

  // 3. Handle Form Submit
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    saveBtn.disabled = true;
    saveBtn.innerText = 'Saving...';
    statusMessage.style.display = 'none';

    chrome.storage.local.get(['careeros_token'], async (res) => {
      const token = res.careeros_token;
      if (!token) {
        authNotice.style.display = 'block';
        showStatus('Please login to Career OS or enter your token.', 'error');
        saveBtn.disabled = false;
        saveBtn.innerText = '🚀 Save to Career OS Board';
        return;
      }

      try {
        const payload = {
          job_title: titleInput.value.trim(),
          company_name: companyInput.value.trim(),
          location: locationInput.value.trim(),
          status: statusSelect.value,
          job_description: currentDescription || 'Captured via Career OS Extension.',
          job_url: currentUrl
        };

        const response = await fetch(`${API_BASE}/jobs`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(payload)
        });

        const data = await response.json();
        if (!response.ok) {
          throw new Error(data.message || 'Server rejected application record.');
        }

        showStatus('🎉 Job successfully clipped to Career OS Kanban!', 'success');
        setTimeout(() => window.close(), 1800);
      } catch (err) {
        showStatus(err.message, 'error');
        saveBtn.disabled = false;
        saveBtn.innerText = '🚀 Save to Career OS Board';
      }
    });
  });

  function showStatus(text, type) {
    statusMessage.innerText = text;
    statusMessage.className = `status ${type}`;
    statusMessage.style.display = 'block';
  }
});
