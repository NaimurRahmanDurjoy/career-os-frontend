# Career OS Chrome Extension ⚡

The official browser companion for **Career OS**. 1-Click save jobs directly from multiple platforms into your Career OS Kanban board:

## 🌐 Supported Job Sources:
1. 🇧🇩 **Bdjobs (`bdjobs.com`):** Automatically grabs Job Title, Company Name, Location, and full Job Description.
2. 👥 **Facebook (`facebook.com`):** Grabs Job posts from Groups, Pages, or highlighted post text.
3. 💼 **LinkedIn (`linkedin.com`):** Scrapes official unified job postings.
4. 🔍 **Indeed (`indeed.com`):** Extracts job cards and company data.
5. 🏢 **Glassdoor (`glassdoor.com`):** Scrapes job listings and descriptions.
6. 🌐 **Universal Fallback:** Works on Greenhouse, Lever, Workday, or **ANY** company career site by reading page headings and highlighted text.

## 📥 How to Install in Chrome / Edge / Brave:

1. Open Chrome and go to `chrome://extensions/`
2. Toggle on **Developer mode** (top-right corner).
3. Click **Load unpacked** (top-left corner).
4. Select the directory: `e:\laragon\www\career-os-extension`
5. The Career OS Clipper icon will appear in your Chrome toolbar!

## 🚀 How to Use:

1. Open the extension and save your Career OS Token (Bearer Token).
2. Go to any job post on **Bdjobs**, **Facebook**, or **LinkedIn**.
3. Click the extension icon — the fields will pre-fill instantly.
4. Hit **Save to Career OS Board**!
