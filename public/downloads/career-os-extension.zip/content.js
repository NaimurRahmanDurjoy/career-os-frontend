// Career OS Content Scraper Engine & Session Syncer

function cleanText(text) {
  return text ? text.replace(/\s+/g, ' ').trim() : '';
}

// 1. Check if on Career OS domain to automatically grab auth token for extension
function syncCareerOsSession() {
  const isLocalCareerOs = window.location.origin.includes('localhost') || window.location.origin.includes('127.0.0.1');
  const isLiveCareerOs = window.location.origin.includes('careeros.');

  if (isLocalCareerOs || isLiveCareerOs) {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');
    if (token) {
      chrome.storage.local.set({ careeros_token: token, careeros_user: user });
    }
  }
}
syncCareerOsSession();

function extractJobDetails() {
  const url = window.location.href;
  const hostname = window.location.hostname;

  let jobData = {
    title: '',
    company: '',
    location: '',
    salary: '',
    description: '',
    url: url
  };

  // 1. 🇧🇩 BDJOBS SCRAPER (Bangladesh Local Market)
  if (hostname.includes('bdjobs.com')) {
    const titleEl = document.querySelector('.job-title, h2.job-title, .jobdetail-title h1, h1');
    const companyEl = document.querySelector('.company-name, .jobdetail-company-name, h2.company-name, .cname');
    const locationEl = document.querySelector('.job-location, .loc, .jobdetail-location');
    const salaryEl = document.querySelector('.salary-range, .salary, .jobdetail-salary');
    const descEl = document.querySelector('.job-description, .job-details, #job-preview, .preview-content, .job-context');

    jobData.title = cleanText(titleEl?.innerText);
    jobData.company = cleanText(companyEl?.innerText);
    jobData.location = cleanText(locationEl?.innerText || 'Bangladesh');
    jobData.salary = cleanText(salaryEl?.innerText);
    jobData.description = descEl ? cleanText(descEl.innerText).slice(0, 5000) : '';
  }

  // 2. 👥 FACEBOOK SCRAPER (Groups / Pages / Job Posts)
  else if (hostname.includes('facebook.com')) {
    const selectedText = window.getSelection()?.toString();
    const postEl = document.querySelector('div[role="feed"] div[role="article"], div[role="article"], div[data-ad-preview="message"]');
    const postText = postEl?.innerText || selectedText || '';

    const lines = postText.split('\n').map(l => l.trim()).filter(Boolean);
    jobData.title = lines[0] ? lines[0].slice(0, 60) : 'Job Opening from Facebook';
    
    const authorEl = document.querySelector('h2 strong, h3 strong, strong, h2 a, h3 a');
    jobData.company = cleanText(authorEl?.innerText || 'Facebook Recruiter / Group');
    jobData.location = 'Dhaka, Bangladesh / Remote';
    jobData.description = (selectedText || postText || '').slice(0, 5000);
  }

  // 3. 💼 LINKEDIN SCRAPER
  else if (hostname.includes('linkedin.com')) {
    const titleEl = document.querySelector('.job-details-jobs-unified-top-card__job-title, .jobs-unified-top-card__job-title, h1.t-24, h1');
    const companyEl = document.querySelector('.job-details-jobs-unified-top-card__company-name, .jobs-unified-top-card__company-name, .job-details-jobs-unified-top-card__primary-description a');
    const locationEl = document.querySelector('.job-details-jobs-unified-top-card__primary-description-container span, .jobs-unified-top-card__bullet');
    const descEl = document.querySelector('#job-details, .jobs-description__content, .jobs-box__html-content');

    jobData.title = cleanText(titleEl?.innerText);
    jobData.company = cleanText(companyEl?.innerText);
    jobData.location = cleanText(locationEl?.innerText);
    jobData.description = descEl ? cleanText(descEl.innerText).slice(0, 5000) : '';
  }

  // 4. 🔍 INDEED SCRAPER
  else if (hostname.includes('indeed.com')) {
    const titleEl = document.querySelector('h1.jobsearch-JobInfoHeader-title, h2.jobTitle, h1');
    const companyEl = document.querySelector('[data-testid="inlineHeader-companyName"], .companyName');
    const locationEl = document.querySelector('[data-testid="inlineHeader-companyLocation"], .companyLocation');
    const descEl = document.querySelector('#jobDescriptionText');

    jobData.title = cleanText(titleEl?.innerText);
    jobData.company = cleanText(companyEl?.innerText);
    jobData.location = cleanText(locationEl?.innerText);
    jobData.description = descEl ? cleanText(descEl.innerText).slice(0, 5000) : '';
  }

  // 5. 🏢 GLASSDOOR SCRAPER
  else if (hostname.includes('glassdoor.com')) {
    const titleEl = document.querySelector('h1.heading_Heading__header__D6Gjh, h1');
    const companyEl = document.querySelector('.EmployerProfile_employerNameContainer__aRzX9, .EmployerProfile_employerName__8Aaf6');
    const locationEl = document.querySelector('.JobDetails_location__mSg5h');
    const descEl = document.querySelector('.JobDetails_jobDescription__uWShared, .desc');

    jobData.title = cleanText(titleEl?.innerText);
    jobData.company = cleanText(companyEl?.innerText);
    jobData.location = cleanText(locationEl?.innerText);
    jobData.description = descEl ? cleanText(descEl.innerText).slice(0, 5000) : '';
  }

  // 6. 🌐 UNIVERSAL FALLBACK
  else {
    const selectedText = window.getSelection()?.toString();
    const h1El = document.querySelector('h1');
    const metaTitle = document.title;

    jobData.title = cleanText(h1El?.innerText || metaTitle.split(/[-|–]/)[0] || 'Job Opening');
    jobData.company = cleanText(metaTitle.split(/[-|–]/)[1] || hostname.replace('www.', '').split('.')[0]);
    jobData.location = 'On-site / Remote';
    
    const mainEl = document.querySelector('main, article, #content, .content, body');
    jobData.description = cleanText(selectedText || mainEl?.innerText || '').slice(0, 5000);
  }

  if (!jobData.description) {
    const selectedText = window.getSelection()?.toString();
    if (selectedText) jobData.description = cleanText(selectedText);
  }

  return jobData;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'SCRAPE_CURRENT_PAGE') {
    const details = extractJobDetails();
    sendResponse({ success: true, data: details });
  }
  return true;
});
